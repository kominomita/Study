// Shared types + localStorage helpers for Study Focus

export type Mode = 'focus' | 'short' | 'long'

export interface Task {
  id: string
  title: string
  estimate: number // pomodoros estimated
  done: number // pomodoros completed on this task
  completed: boolean
}

export interface DayStat {
  date: string // YYYY-MM-DD
  minutes: number
  sessions: number
}

const TASKS_KEY = 'sf.tasks'
const STATS_KEY = 'sf.stats'
const DUR_KEY = 'sf.durations'

export function todayKey(d = new Date()): string {
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}

export function loadTasks(): Task[] {
  try {
    const raw = localStorage.getItem(TASKS_KEY)
    if (!raw) return []
    const parsed = JSON.parse(raw) as { date: string; tasks: Task[] }
    if (parsed.date !== todayKey()) return [] // fresh plan each day
    return parsed.tasks
  } catch {
    return []
  }
}

export function saveTasks(tasks: Task[]) {
  localStorage.setItem(TASKS_KEY, JSON.stringify({ date: todayKey(), tasks }))
}

export function loadStats(): Record<string, DayStat> {
  try {
    const raw = localStorage.getItem(STATS_KEY)
    return raw ? (JSON.parse(raw) as Record<string, DayStat>) : {}
  } catch {
    return {}
  }
}

export function recordSession(minutes: number): Record<string, DayStat> {
  const stats = loadStats()
  const key = todayKey()
  const prev = stats[key] ?? { date: key, minutes: 0, sessions: 0 }
  stats[key] = { date: key, minutes: prev.minutes + minutes, sessions: prev.sessions + 1 }
  // keep last 30 days
  const keys = Object.keys(stats).sort().slice(-30)
  const trimmed: Record<string, DayStat> = {}
  keys.forEach((k) => (trimmed[k] = stats[k]))
  localStorage.setItem(STATS_KEY, JSON.stringify(trimmed))
  return trimmed
}

export function last7Days(stats: Record<string, DayStat>): DayStat[] {
  const out: DayStat[] = []
  for (let i = 6; i >= 0; i--) {
    const d = new Date()
    d.setDate(d.getDate() - i)
    const key = todayKey(d)
    out.push(stats[key] ?? { date: key, minutes: 0, sessions: 0 })
  }
  return out
}

export function loadDurations(): Record<Mode, number> {
  try {
    const raw = localStorage.getItem(DUR_KEY)
    if (raw) return JSON.parse(raw) as Record<Mode, number>
  } catch {
    /* ignore */
  }
  return { focus: 25, short: 5, long: 15 }
}

export function saveDurations(d: Record<Mode, number>) {
  localStorage.setItem(DUR_KEY, JSON.stringify(d))
}

export function uid(): string {
  return Math.random().toString(36).slice(2, 10)
}

/** Soft two-tone chime via WebAudio */
export function playChime() {
  try {
    const Ctx = window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext
    const ctx = new Ctx()
    const notes = [523.25, 659.25, 783.99]
    notes.forEach((freq, i) => {
      const osc = ctx.createOscillator()
      const gain = ctx.createGain()
      osc.type = 'sine'
      osc.frequency.value = freq
      const t = ctx.currentTime + i * 0.18
      gain.gain.setValueAtTime(0.0001, t)
      gain.gain.exponentialRampToValueAtTime(0.25, t + 0.02)
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.5)
      osc.connect(gain).connect(ctx.destination)
      osc.start(t)
      osc.stop(t + 0.55)
    })
  } catch {
    /* audio unavailable */
  }
}

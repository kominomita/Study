import { useEffect, useRef, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Play, Pause, RotateCcw, SkipForward, Settings2 } from 'lucide-react'
import type { Mode, Task } from '@/lib/study'
import { loadDurations, saveDurations, playChime } from '@/lib/study'

const MODE_LABEL: Record<Mode, string> = { focus: 'Focus', short: 'Short break', long: 'Long break' }
const MODE_COLOR: Record<Mode, string> = { focus: '#d4551f', short: '#2e7d4f', long: '#2f5f8f' }

interface Props {
  activeTask: Task | null
  onFocusComplete: () => void
  onBreakComplete: () => void
  cycleCount: number
}

export default function TimerSection({ activeTask, onFocusComplete, onBreakComplete, cycleCount }: Props) {
  const [durations, setDurations] = useState<Record<Mode, number>>(loadDurations)
  const [mode, setMode] = useState<Mode>('focus')
  const [secondsLeft, setSecondsLeft] = useState(durations.focus * 60)
  const [running, setRunning] = useState(false)
  const endRef = useRef<number | null>(null)
  const total = durations[mode] * 60

  useEffect(() => {
    if (!running) return
    endRef.current = Date.now() + secondsLeft * 1000
    const tick = window.setInterval(() => {
      const left = Math.max(0, Math.round(((endRef.current ?? 0) - Date.now()) / 1000))
      setSecondsLeft(left)
      if (left <= 0) {
        window.clearInterval(tick)
        setRunning(false)
        playChime()
        if (mode === 'focus') {
          onFocusComplete()
          const next: Mode = (cycleCount + 1) % 4 === 0 ? 'long' : 'short'
          setMode(next)
          setSecondsLeft(loadDurations()[next] * 60)
        } else {
          onBreakComplete()
          setMode('focus')
          setSecondsLeft(loadDurations().focus * 60)
        }
      }
    }, 250)
    return () => window.clearInterval(tick)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [running])

  useEffect(() => {
    const mm = String(Math.floor(secondsLeft / 60)).padStart(2, '0')
    const ss = String(secondsLeft % 60).padStart(2, '0')
    document.title = running ? `${mm}:${ss} · ${MODE_LABEL[mode]}` : 'Study Focus'
  }, [secondsLeft, running, mode])

  function switchMode(m: Mode) {
    setMode(m)
    setRunning(false)
    setSecondsLeft(durations[m] * 60)
  }

  function reset() {
    setRunning(false)
    setSecondsLeft(durations[mode] * 60)
  }

  function applyDurations(d: Record<Mode, number>) {
    setDurations(d)
    saveDurations(d)
    setRunning(false)
    setSecondsLeft(d[mode] * 60)
  }

  const mm = String(Math.floor(secondsLeft / 60)).padStart(2, '0')
  const ss = String(secondsLeft % 60).padStart(2, '0')
  const progress = 1 - secondsLeft / total
  const R = 150
  const CIRC = 2 * Math.PI * R
  const color = MODE_COLOR[mode]

  return (
    <section className="flex flex-col items-center">
      {/* mode switch */}
      <div className="flex gap-1 rounded-full border border-[#ddd5c4] bg-[#efe9db] p-1">
        {(Object.keys(MODE_LABEL) as Mode[]).map((m) => (
          <button
            key={m}
            onClick={() => switchMode(m)}
            className={`rounded-full px-4 py-1.5 text-sm font-medium tracking-wide transition-colors ${
              mode === m ? 'bg-[#1c1c1c] text-[#f7f3ea]' : 'text-[#6b6558] hover:text-[#1c1c1c]'
            }`}
          >
            {MODE_LABEL[m]}
          </button>
        ))}
      </div>

      {/* ring */}
      <div className="relative mt-10">
        <svg width="360" height="360" viewBox="0 0 360 360" className="max-w-[78vw]">
          <circle cx="180" cy="180" r={R} fill="none" stroke="#e2dac8" strokeWidth="10" />
          <circle
            cx="180"
            cy="180"
            r={R}
            fill="none"
            stroke={color}
            strokeWidth="10"
            strokeLinecap="round"
            strokeDasharray={CIRC}
            strokeDashoffset={CIRC * (1 - progress)}
            transform="rotate(-90 180 180)"
            style={{ transition: 'stroke-dashoffset 0.3s linear, stroke 0.3s' }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <div
            className="font-semibold tabular-nums leading-none tracking-tight text-[#1c1c1c]"
            style={{ fontSize: 'clamp(4rem, 14vw, 6.5rem)', fontVariantNumeric: 'tabular-nums' }}
          >
            {mm}:{ss}
          </div>
          <div className="mt-3 max-w-[220px] truncate text-center text-sm tracking-wide text-[#6b6558]">
            {mode === 'focus'
              ? activeTask
                ? `Working on: ${activeTask.title}`
                : 'Pick a task below, or just start'
              : 'Step away. Breathe. Stretch.'}
          </div>
        </div>
      </div>

      {/* controls */}
      <div className="mt-8 flex items-center gap-3">
        <Button variant="outline" size="icon" onClick={reset} className="h-11 w-11 rounded-full border-[#d8d0bd] bg-transparent hover:bg-[#e9e2d1]">
          <RotateCcw className="h-4 w-4" />
        </Button>
        <Button
          onClick={() => setRunning((r) => !r)}
          className="h-14 rounded-full px-10 text-base font-semibold"
          style={{ background: color, color: '#fdfbf5' }}
        >
          {running ? <Pause className="mr-2 h-5 w-5" /> : <Play className="mr-2 h-5 w-5" />}
          {running ? 'Pause' : secondsLeft < total ? 'Resume' : 'Start'}
        </Button>
        <Button
          variant="outline"
          size="icon"
          onClick={() => {
            if (mode === 'focus') onFocusComplete()
            const next: Mode = mode === 'focus' ? 'short' : 'focus'
            switchMode(next)
          }}
          className="h-11 w-11 rounded-full border-[#d8d0bd] bg-transparent hover:bg-[#e9e2d1]"
        >
          <SkipForward className="h-4 w-4" />
        </Button>
      </div>

      {/* settings */}
      <Dialog>
        <DialogTrigger asChild>
          <button className="mt-6 flex items-center gap-1.5 text-xs tracking-widest text-[#8a8272] uppercase hover:text-[#1c1c1c]">
            <Settings2 className="h-3.5 w-3.5" /> Durations
          </button>
        </DialogTrigger>
        <DialogContent className="bg-[#f7f3ea] sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Session lengths (minutes)</DialogTitle>
          </DialogHeader>
          <DurationForm durations={durations} onSave={applyDurations} />
        </DialogContent>
      </Dialog>
    </section>
  )
}

function DurationForm({ durations, onSave }: { durations: Record<Mode, number>; onSave: (d: Record<Mode, number>) => void }) {
  const [f, setF] = useState(durations.focus)
  const [s, setS] = useState(durations.short)
  const [l, setL] = useState(durations.long)
  return (
    <div className="space-y-4">
      {([
        ['Focus', f, setF],
        ['Short break', s, setS],
        ['Long break', l, setL],
      ] as const).map(([label, val, setter]) => (
        <div key={label} className="flex items-center justify-between gap-4">
          <span className="text-sm">{label}</span>
          <Input
            type="number"
            min={1}
            max={120}
            value={val}
            onChange={(e) => setter(Math.max(1, Math.min(120, Number(e.target.value) || 1)))}
            className="w-20 border-[#d8d0bd] bg-white"
          />
        </div>
      ))}
      <Button className="w-full bg-[#1c1c1c] text-[#f7f3ea]" onClick={() => onSave({ focus: f, short: s, long: l })}>
        Save
      </Button>
    </div>
  )
}

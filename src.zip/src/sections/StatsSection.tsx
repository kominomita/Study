import type { DayStat } from '@/lib/study'
import { last7Days } from '@/lib/study'

const DAY_LETTERS = ['S', 'M', 'T', 'W', 'T', 'F', 'S']

export default function StatsSection({ stats }: { stats: Record<string, DayStat> }) {
  const week = last7Days(stats)
  const today = week[6]
  const maxMin = Math.max(30, ...week.map((d) => d.minutes))

  // streak: consecutive days with sessions ending today
  let streak = 0
  for (let i = 6; i >= 0; i--) {
    if (week[i].sessions > 0) streak++
    else if (i !== 6) break
    else continue // today may not have started yet
  }
  // recompute properly: count back from yesterday if today empty
  streak = 0
  const startIdx = today.sessions > 0 ? 6 : 5
  for (let i = startIdx; i >= 0; i--) {
    if (week[i].sessions > 0) streak++
    else break
  }

  return (
    <section className="rounded-2xl border border-[#ddd5c4] bg-[#f7f3ea] p-6">
      <h2 className="text-sm font-semibold tracking-[0.2em] text-[#6b6558] uppercase">Today</h2>

      <div className="mt-4 grid grid-cols-3 gap-3">
        <div className="rounded-xl bg-[#efe9db] p-4 text-center">
          <div className="text-3xl font-semibold tabular-nums text-[#1c1c1c]">{today.minutes}</div>
          <div className="mt-1 text-xs tracking-wider text-[#8a8272]">minutes</div>
        </div>
        <div className="rounded-xl bg-[#efe9db] p-4 text-center">
          <div className="text-3xl font-semibold tabular-nums text-[#1c1c1c]">{today.sessions}</div>
          <div className="mt-1 text-xs tracking-wider text-[#8a8272]">sessions</div>
        </div>
        <div className="rounded-xl bg-[#efe9db] p-4 text-center">
          <div className="text-3xl font-semibold tabular-nums text-[#1c1c1c]">{streak}</div>
          <div className="mt-1 text-xs tracking-wider text-[#8a8272]">day streak</div>
        </div>
      </div>

      <div className="mt-6">
        <div className="text-xs tracking-wider text-[#8a8272]">Last 7 days (focused minutes)</div>
        <div className="mt-3 flex h-28 items-end gap-2">
          {week.map((d, i) => {
            const date = new Date(d.date + 'T00:00:00')
            const isToday = i === 6
            return (
              <div key={d.date} className="flex flex-1 flex-col items-center gap-1.5">
                <span className="text-[10px] tabular-nums text-[#8a8272]">{d.minutes || ''}</span>
                <div
                  className="w-full rounded-t-md transition-all"
                  style={{
                    height: `${Math.max(3, (d.minutes / maxMin) * 72)}px`,
                    background: isToday ? '#d4551f' : '#cdc3ab',
                  }}
                />
                <span className={`text-[10px] ${isToday ? 'font-bold text-[#1c1c1c]' : 'text-[#8a8272]'}`}>
                  {DAY_LETTERS[date.getDay()]}
                </span>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}

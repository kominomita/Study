import { useState } from 'react'
import { Input } from '@/components/ui/input'
import { Checkbox } from '@/components/ui/checkbox'
import { Plus, Trash2, Target } from 'lucide-react'
import type { Task } from '@/lib/study'
import { uid } from '@/lib/study'

interface Props {
  tasks: Task[]
  setTasks: (t: Task[]) => void
  activeId: string | null
  setActiveId: (id: string | null) => void
}

export default function TasksSection({ tasks, setTasks, activeId, setActiveId }: Props) {
  const [title, setTitle] = useState('')

  function add() {
    const t = title.trim()
    if (!t) return
    setTasks([...tasks, { id: uid(), title: t, estimate: 1, done: 0, completed: false }])
    setTitle('')
  }

  const remaining = tasks.filter((t) => !t.completed).length

  return (
    <section className="rounded-2xl border border-[#ddd5c4] bg-[#f7f3ea] p-6">
      <div className="flex items-baseline justify-between">
        <h2 className="text-sm font-semibold tracking-[0.2em] text-[#6b6558] uppercase">Today's plan</h2>
        <span className="text-xs text-[#8a8272]">{remaining} left</span>
      </div>

      <div className="mt-4 flex gap-2">
        <Input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && add()}
          placeholder="Add a study task…"
          className="border-[#d8d0bd] bg-white placeholder:text-[#a89f8c]"
        />
        <button
          onClick={add}
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md bg-[#1c1c1c] text-[#f7f3ea] hover:bg-[#333]"
          aria-label="Add task"
        >
          <Plus className="h-4 w-4" />
        </button>
      </div>

      <ul className="mt-4 divide-y divide-[#e5ddcb]">
        {tasks.length === 0 && (
          <li className="py-8 text-center text-sm text-[#a89f8c]">
            No tasks yet — write down what you'll study today.
          </li>
        )}
        {tasks.map((task) => (
          <li key={task.id} className="group flex items-center gap-3 py-3">
            <Checkbox
              checked={task.completed}
              onCheckedChange={(c) =>
                setTasks(tasks.map((t) => (t.id === task.id ? { ...t, completed: !!c } : t)))
              }
              className="border-[#b8ae97] data-[state=checked]:bg-[#2e7d4f] data-[state=checked]:border-[#2e7d4f]"
            />
            <button
              onClick={() => setActiveId(activeId === task.id ? null : task.id)}
              className={`flex-1 text-left text-sm transition-colors ${
                task.completed
                  ? 'text-[#a89f8c] line-through'
                  : activeId === task.id
                    ? 'font-semibold text-[#d4551f]'
                    : 'text-[#1c1c1c]'
              }`}
              title="Set as current focus"
            >
              {task.title}
            </button>
            {activeId === task.id && !task.completed && (
              <Target className="h-3.5 w-3.5 shrink-0 text-[#d4551f]" />
            )}
            <span className="flex shrink-0 items-center gap-1">
              {Array.from({ length: Math.max(task.estimate, task.done) }).map((_, i) => (
                <span
                  key={i}
                  className={`h-1.5 w-1.5 rounded-full ${i < task.done ? 'bg-[#d4551f]' : 'bg-[#ddd5c4]'}`}
                />
              ))}
            </span>
            <button
              onClick={() => setTasks(tasks.map((t) => (t.id === task.id ? { ...t, estimate: t.estimate + 1 } : t)))}
              className="shrink-0 rounded px-1 text-xs text-[#a89f8c] opacity-0 transition-opacity group-hover:opacity-100 hover:text-[#1c1c1c]"
              title="+1 pomodoro estimate"
            >
              +🍅
            </button>
            <button
              onClick={() => {
                setTasks(tasks.filter((t) => t.id !== task.id))
                if (activeId === task.id) setActiveId(null)
              }}
              className="shrink-0 text-[#c9bfa9] opacity-0 transition-opacity group-hover:opacity-100 hover:text-[#b0401a]"
              aria-label="Delete task"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </li>
        ))}
      </ul>
    </section>
  )
}

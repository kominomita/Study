import { useEffect, useMemo, useState } from 'react'
import TimerSection from '@/sections/TimerSection'
import TasksSection from '@/sections/TasksSection'
import StatsSection from '@/sections/StatsSection'
import type { DayStat, Task } from '@/lib/study'
import { loadStats, loadTasks, recordSession, saveTasks, loadDurations } from '@/lib/study'

function greeting(): string {
  const h = new Date().getHours()
  if (h < 6) return 'Late night session'
  if (h < 12) return 'Good morning'
  if (h < 18) return 'Good afternoon'
  return 'Good evening'
}

export default function Home() {
  const [tasks, setTasksState] = useState<Task[]>(loadTasks)
  const [activeId, setActiveId] = useState<string | null>(null)
  const [stats, setStats] = useState<Record<string, DayStat>>(loadStats)
  const [cycleCount, setCycleCount] = useState(0)
  const [now, setNow] = useState(new Date())

  useEffect(() => {
    const t = window.setInterval(() => setNow(new Date()), 30000)
    return () => window.clearInterval(t)
  }, [])

  function setTasks(t: Task[]) {
    setTasksState(t)
    saveTasks(t)
  }

  function onFocusComplete() {
    const focusMin = loadDurations().focus
    setStats(recordSession(focusMin))
    setCycleCount((c) => c + 1)
    if (activeId) {
      setTasks(tasks.map((t) => (t.id === activeId ? { ...t, done: t.done + 1 } : t)))
    }
  }

  function onBreakComplete() {
    // nothing to record, hook kept for symmetry
  }

  const activeTask = useMemo(() => tasks.find((t) => t.id === activeId) ?? null, [tasks, activeId])
  const dateStr = now.toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })

  return (
    <div className="min-h-screen bg-[#e9e2d1] text-[#1c1c1c]">
      <div className="mx-auto max-w-5xl px-4 py-6 sm:px-5 sm:py-8 md:py-12">
        {/* header */}
        <header className="flex flex-wrap items-baseline justify-between gap-2 border-b border-[#d5ccB8] pb-5" style={{ borderColor: '#d5ccb8' }}>
          <div>
            <h1 className="text-xl font-bold tracking-tight">Study Focus</h1>
            <p className="mt-0.5 text-sm text-[#6b6558]">
              {greeting()} · {dateStr}
            </p>
          </div>
          <div className="text-sm tabular-nums text-[#6b6558]">
            {now.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' })}
          </div>
        </header>

        <div className="mt-6 grid gap-8 md:mt-8 md:grid-cols-[1.2fr_1fr] md:gap-10">
          <TimerSection
            activeTask={activeTask}
            onFocusComplete={onFocusComplete}
            onBreakComplete={onBreakComplete}
            cycleCount={cycleCount}
          />
          <div className="space-y-6">
            <TasksSection tasks={tasks} setTasks={setTasks} activeId={activeId} setActiveId={setActiveId} />
            <StatsSection stats={stats} />
          </div>
        </div>

        <footer className="mt-12 border-t pt-5 text-center text-xs text-[#8a8272]" style={{ borderColor: '#d5ccb8' }}>
          Every 4 focus sessions earns a long break. Your plan resets each morning; stats stay.
        </footer>
      </div>
    </div>
  )
}
